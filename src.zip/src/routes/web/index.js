const express = require('express')

const router = express.Router()

const v1Routes = require('./v1/index');


router.use('/web', v1Routes)

module.exports = router